import time
import pytest


@pytest.fixture(scope="session", autouse=True)
def track_suite_time():
    start = time.time()
    print("\n[SUITE] Test suite started...")
    yield
    end = time.time()
    duration = end - start
    print(f"[SUITE] Test suite finished in {duration:.2f} seconds.")


@pytest.fixture()
def track_test_time(request):
    start = time.time()
    print(f"\n[TEST] Test '{request.node.name}' started...")
    yield
    end = time.time()
    duration = end - start
    print(f"[TEST] Test '{request.node.name}' finished in {duration:.2f} seconds.")


def add_numbers(a, b):
    return a + b


@pytest.mark.usefixtures("track_test_time")
def test_add_two_positive_numbers():
    a, b = 3, 5
    result = add_numbers(a, b)
    time.sleep(2)
    assert result == 8


@pytest.mark.usefixtures("track_test_time")
def test_add_two_negative_numbers():
    a, b = -3, -5
    result = add_numbers(a, b)
    time.sleep(3)
    assert result == -8


def test_add_negative_and_positive_numbers():
    a, b = -3, 5
    result = add_numbers(a, b)
    time.sleep(10)
    assert result == 2
