import pytest
import yaml


# Load test data from YAML file
with open("config.yaml") as f:
    data = yaml.safe_load(f)


def add_numbers(*args):
    return sum(args)


@pytest.mark.smoke
@pytest.mark.parametrize(
    "a,b,c,expected",
    [(case["input"][0], case["input"][1], case["input"][2], case["expected"]) for case in data["cases"]],
    ids=[case["case_name"] for case in data["cases"]]
)
def test_add_numbers(a, b, c, expected):
    result = add_numbers(a, b, c)
    assert result == expected


@pytest.mark.critical
def test_add_invalid_types():
    with pytest.raises(TypeError):
        add_numbers(1, "two", 3)
