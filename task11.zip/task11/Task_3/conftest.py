import pytest
import psycopg2
import yaml

@pytest.fixture(scope='session')
def db_connection():
    conn = psycopg2.connect(
        host="localhost",
        database="dwh_hw_db",
        user="dwh_hw_user",
        password="12345678"
    )
    yield conn
    conn.close()

@pytest.fixture(scope='session')
def load_sql_queries():
    with open("config_sql.yaml", "r") as f:
        return yaml.safe_load(f)
