import pytest

@pytest.mark.parametrize("query_name", [
    "check_tables_exist",
    "check_schemas_exist",
    "check_row_count_positive"
])
@pytest.mark.smoke
def test_smoke_queries(db_connection, load_sql_queries, query_name):
    query = load_sql_queries["smoke_tests"][query_name]
    with db_connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()
        assert result[0], f"Smoke test '{query_name}' failed!"


@pytest.mark.parametrize("query_name", [
    "check_null_values",
    "check_duplicates",
    "check_row_counts_match"
])
@pytest.mark.critical
def test_critical_queries(db_connection, load_sql_queries, query_name):
    query = load_sql_queries["critical_tests"][query_name]
    with db_connection.cursor() as cursor:
        cursor.execute(query)
        result = cursor.fetchone()
        assert result[0], f"Critical test '{query_name}' failed!"
