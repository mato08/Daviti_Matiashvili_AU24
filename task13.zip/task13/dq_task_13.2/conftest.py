import pytest
import yaml
import psycopg2


#  Database connection fixture
@pytest.fixture(scope="session")
def db_conn():
    conn = psycopg2.connect(
        dbname="dwh_hw_db",
        user="dwh_hw_user",
        password="12345678",
        host="localhost",
        port=5432
    )
    yield conn
    conn.close()



def load_sql_queries():
    with open("Configs/config_SQL_example.yaml", "r") as f:
        return yaml.safe_load(f)



# provide full config as fixture
@pytest.fixture(scope="session")
def sql_queries():
    return load_sql_queries()

# Split smoke and critical test fixtures
@pytest.fixture(scope="session")
def smoke_queries(sql_queries):
    return sql_queries["smoke_tests"]

@pytest.fixture(scope="session")
def critical_queries(sql_queries):
    return sql_queries["critical_tests"]