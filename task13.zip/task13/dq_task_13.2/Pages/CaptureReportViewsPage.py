from selenium.webdriver.support.ui import WebDriverWait as WDW
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import *
import time

class CaptureReportViewsPage:
    def __init__(self, driver, delay):
        self.driver = driver
        self.delay = delay

        # Clean XPaths targeting the <span> text directly
        self.total_category_volume_region_title = "//span[contains(text(), 'Total Category Volume Over Time by Region')]"
        self.category_breakdown_title = "//span[contains(text(), 'Category Breakdown')]"

        # Locators for switching frames
        self.first_frame_class = "showcase-frame"
        self.second_frame_css = "iframe[src*='app.powerbi.com']"

    def switch_to_report_frame(self):
        """Switch into the nested iframe that contains the Power BI report."""
        first_frame = WDW(self.driver, self.delay).until(
            EC.presence_of_element_located((By.CLASS_NAME, self.first_frame_class))
        )
        self.driver.switch_to.frame(first_frame)

        second_frame = WDW(self.driver, self.delay).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, self.second_frame_css))
        )
        self.driver.switch_to.frame(second_frame)

        time.sleep(5)

    def get_total_category_volume_region_title(self):
        report_header = WDW(self.driver, self.delay).until(
            EC.presence_of_element_located((By.XPATH, self.total_category_volume_region_title))
        )
        return report_header.text.strip()

    def get_category_breakdown_title(self):
        report_header = WDW(self.driver, self.delay).until(
            EC.presence_of_element_located((By.XPATH, self.category_breakdown_title))
        )
        return report_header.text.strip()
