import pytest
import allure
from conftest import load_sql_queries


# test data
queries = load_sql_queries()
smoke_cases = queries["smoke_tests"]
critical_cases = queries["critical_tests"]


# smoke tests
@pytest.mark.smoke
@pytest.mark.parametrize(
    "test_case",
    [pytest.param(case, id=case["name"]) for case in smoke_cases]
)
def test_each_smoke_case(test_case, db_conn):
    with allure.step(f"Running: {test_case['name']}"):
        cursor = db_conn.cursor()
        cursor.execute(test_case["query"])
        result = cursor.fetchone()
        cursor.close()
        assert result is not None, f"No result returned for {test_case['name']}"
        assert result[0] == test_case["expected"], f"{test_case['name']}: Expected {test_case['expected']}, got {result[0]}"


# critical tests
@pytest.mark.critical
@pytest.mark.parametrize(
    "test_case",
    [pytest.param(case, id=case["name"]) for case in critical_cases]
)
def test_each_critical_case(test_case, db_conn):
    with allure.step(f"Running: {test_case['name']}"):
        cursor = db_conn.cursor()
        cursor.execute(test_case["query"])
        result = cursor.fetchone()
        cursor.close()
        assert result is not None, f"No result returned for {test_case['name']}"
        assert result[0] == test_case["expected"], f"{test_case['name']}: Expected {test_case['expected']}, got {result[0]}"
