# Tests/test_capture_report_views_page.py

import os
import sys
import yaml
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager
from Pages.CaptureReportViewsPage import CaptureReportViewsPage


def get_selenium_config(config_name):
    module_dir = os.path.dirname(os.path.abspath(sys.modules[__name__].__file__))
    project_root = os.path.dirname(os.path.dirname(module_dir))
    with open(os.path.join(project_root, 'Configs', config_name), 'r') as stream:
        config = yaml.safe_load(stream)
    return config['global']



@pytest.fixture(scope="function")
def open_capture_report_views_webpage():
    report_uri = get_selenium_config('config_selenium.yaml')['report_uri']
    delay = get_selenium_config('config_selenium.yaml')['delay']

    # ✅ Correct ChromeDriver initialization
    driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))
    driver.set_window_size(1024, 600)
    driver.maximize_window()
    driver.get(report_uri)

    capture_report_page = CaptureReportViewsPage(driver, delay)
    yield capture_report_page
    driver.quit()


def test_01_check_total_category_volume_region_title(open_capture_report_views_webpage):
    report_page = open_capture_report_views_webpage
    report_page.switch_to_report_frame()
    report_title = report_page.get_total_category_volume_region_title()
    assert report_title == 'Total Category Volume Over Time by Region'


def test_02_check_category_breakdown_title(open_capture_report_views_webpage):
    report_page = open_capture_report_views_webpage
    report_page.switch_to_report_frame()
    category_title = report_page.get_category_breakdown_title()
    assert category_title == 'Category Breakdown'
